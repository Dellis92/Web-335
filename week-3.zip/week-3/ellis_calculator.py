def add(a,b):
    return a+b


def subtract(c,d):
    return c-d


def divide(e,f):
    return e/f


def multiply(g,h):
    return g*h

print(add(1,2))
print(subtract(5,3))
print(divide(9,3))
print(multiply(3,5))